def main(event, context): return 'ok'
